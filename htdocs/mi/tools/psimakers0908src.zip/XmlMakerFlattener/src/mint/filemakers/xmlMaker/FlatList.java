package mint.filemakers.xmlMaker;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;
/**
 * Display a line of a flat file in a list (each field in a cell).
 * 
 * <note>The separator is used as a regular expression, so for example a full string could be used,
 * or a regular expression such as ";|.|," . It also means that a separator such as "|" has to be
 *  protected, i.e. "\|". </note>
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 */
public class FlatList extends JPanel {

	/** dimension for buttons */
	private final Dimension buttonsDimension = new Dimension(180, 25);

	/*
	 * management of a line
	 */
	private String line;
	private String separator = null;
	private String path = null;

	/**
	 * set the line to display in the list. The line will be splited according to the separator
	 * and each element will be displayed in a cell
	 * @param aLine the line to split and associate to the list
	 */
	public void setLine(String aLine) {
		line = aLine;

		updateListData();

		Iterator children = internalLists.keySet().iterator();
		while (children.hasNext()) {
			Integer key = (Integer) children.next();
			FlatList child = (FlatList) internalLists.get(key);
			try {
			child.setLine((String) listModel.elementAt(key.intValue()));
			} catch (ArrayIndexOutOfBoundsException e) {
				/** TODO: si rien pour cette ligne on ne fait rien: a verifier */
			}
		}

	}

	/**
	 * set the separator
	 * @param aSeparator the separator
	 */
	public void setSeparator(String aSeparator) {
		separator = aSeparator;
	}

	public String getValue(String path) {

		if (path.indexOf(".") == -1) {
			if (Integer.parseInt(path) < listModel.size()) {
				return (String) listModel.elementAt(Integer.parseInt(path));
			} else { /* element does not exist */
				return null;
			}
		} else {
			Integer index = new Integer(path.substring(0, path.indexOf(".")));
			FlatList subList = ((FlatList) internalLists.get(index));
			String subPath = path.substring(path.indexOf(".") + 1);
			return subList.getValue(subPath);
		}
	}

	/* begining of management of the tabFile */

	/**
	 * contains the sub lists. A cell (key) is associated to a new FlatList (value)
	 */
	private HashMap internalLists = new HashMap();

	private DefaultListModel listModel = new DefaultListModel();
	private JList list = new JList(listModel);

	/**
	 * if this list is a sub list of another one, the parent list is referenced here.
	 */
	private FlatList parent = null;

	/**
	 * return a new intance of a FlatList. If parent is not null,
	 * it means that this list is built on the celll of another list
	 * @param parent
	 */
	public FlatList(FlatList parent, String path) {
		super(new BorderLayout());

		this.parent = parent;

		list.setFixedCellHeight(12);
		list.setFixedCellWidth(60);
		list.setLayoutOrientation(JList.VERTICAL);
		list.setAutoscrolls(true);
		list.setCellRenderer(new MyCellRenderer());
		list.setVisible(true);

		Box buttonsPanel = new Box(BoxLayout.Y_AXIS);

		list.setVisible(true);

		JButton setSeparatorb = new JButton("Set the separator");

		setSeparatorb.setMaximumSize(buttonsDimension);
		setSeparatorb.addActionListener(new setSeparatorListener());

		buttonsPanel.add(setSeparatorb);

		JScrollPane scrollList = new JScrollPane(list);

		add(scrollList, BorderLayout.CENTER);
		add(buttonsPanel, BorderLayout.SOUTH);

		if (path != null)
			this.path = path;
	}

	/**
	 * used to set the separator
	 */
	private class setSeparatorListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {

			String s =
				(String) JOptionPane.showInputDialog(
					new JFrame("[PSI makers: PSI maker] Flat File"),
					"Separator (use regular expression, e.g.: ; ;|:|, \\| ",
					separator);

			if (s != null)
				try {
					setSeparator(s);

					if (line != null) {
						setListData();
					}
				} catch (java.util.regex.PatternSyntaxException ex) {
					JOptionPane.showMessageDialog(
						new JFrame(),
						"the separator specified is not a valid regular expression.",
						"Separator",
						JOptionPane.ERROR_MESSAGE);
				}
		}
	}

	/**
	 * remove all elements from the list and rebuilt it
	 */
	private void setListData() {
		int i = 0;
		listModel.removeAllElements();
		if (separator == null)
			listModel.addElement(line);
		else {
			String[] l = line.split(separator);
			for (i = 0; i < l.length; i++) {
				listModel.addElement(l[i].trim());
			}
		}
	}

	/**
	 * update values of the cells, create new ones 
	 * or delete some if necessary
	 */
	private void updateListData() {

		if (separator == null) {
			listModel.removeAllElements();
			listModel.addElement(line);
			//			numberOfFields = 1;
		} else {
			String[] l = line.split(separator);
			int i = 0;

			while (i < l.length) {
				if (i < listModel.getSize()) {
					listModel.set(i, l[i].trim());
					i++;
				} else {
					listModel.addElement(l[i].trim());
					i++;
				}
			}

			while (i < listModel.getSize()) {
				listModel.set(i, "");
				/* if I had set it to null, it would be seen on the list */
				i++;
			}
		}
	}

	/**
	 * get the path from this list to the one it comes from
	 * @return the path describing the lists as a string of form
	 * indexInFirstList.indexInSecondList.[].indexInParentList
	 */
	public String getSelectedPath() {
		String index = String.valueOf(list.getSelectedIndex());
		if (parent == null)
			return index;
		else
			return parent.getSelectedPath() + "." + index;
	}

	/* Cell Renderer */
	class MyCellRenderer extends JLabel implements ListCellRenderer {

		public Component getListCellRendererComponent(
			JList list,
			Object value,
			int index,
			boolean isSelected,
			boolean cellHasFocus) {
			try {
				setToolTipText(value.toString());
				String s = value.toString();
				setText(s);
			} catch (NullPointerException npe) {
				/* no value */
			}

			if (isSelected) {
				setBackground(list.getSelectionBackground());
				setForeground(list.getSelectionForeground());
			} else {
				setBackground(list.getBackground());
				setForeground(list.getForeground());
			}

			setEnabled(list.isEnabled());
			setFont(list.getFont());
			setOpaque(true);
			return this;
		}
	}

	public FlatList getChildList() {
		if (list.getSelectedIndex() < 0)
			return null;

		FlatList child =
			(FlatList) internalLists.get(new Integer(list.getSelectedIndex()));

		if (child == null) {
			if (this.path != null) {
				child =
					new FlatList(
						this,
						this.path + "." + list.getSelectedIndex());
			} else {
				child = new FlatList(this, "" + list.getSelectedIndex());
			}
			child.setLine(
				(String) listModel.elementAt(list.getSelectedIndex()));
			internalLists.put(new Integer(list.getSelectedIndex()), child);
		}
		return child;
	}

	public FlatList getParentList() {
		return parent;
	}

	public String getFieldsIndex() {
		String fields = "";
		for (int i = 0; i < listModel.getSize(); i++) {
			FlatList child = (FlatList) internalLists.get(new Integer(i));

			if (child != null) {
				fields += child.getFieldsIndex();
			} else if (this.path != null) {
				fields += "\"" + this.path + "." + i + "\"";
			} else {
				fields += "\"" + i + "\"";
			}
			if (i < listModel.getSize() - 1) {
				fields += separator;
			}
		}
		return fields;
	}

	public String getSelectedValue() {
		if (list.getSelectedIndex() < 0)
			return null;

		return (String) list.getSelectedValue();
	}

	public void save(ObjectOutputStream oos) {
		try {
			oos.writeObject(path);
			oos.writeObject(separator);

			Set internalListKeys = internalLists.keySet();
			oos.writeInt(internalListKeys.size());
			Iterator itKeys = internalListKeys.iterator();

			while (itKeys.hasNext()) {
				Integer index = (Integer) itKeys.next();
				oos.writeObject(index);
				((FlatList) internalLists.get(index)).save(oos);
			}
		} catch (IOException e) {
			System.out.println("failed to save");
		}
	}

	public void load(ObjectInputStream ois) {
		try {
			this.path = (String) ois.readObject();
			this.separator = (String) ois.readObject();

			int nbInternalLists = ois.readInt();

			setListData();
//						updateListData();
			for (int i = 0; i < nbInternalLists; i++) {
				//				updateListData();
				Integer index = (Integer) ois.readObject();
				FlatList child =
					new FlatList(this, this.path + "." + index.intValue());
				try {
					child.setLine(
						(String) listModel.elementAt(index.intValue()));
				} catch (ArrayIndexOutOfBoundsException e) {
					/* nothing, the field is empty for this line */
					child.setLine("");
				}
				child.load(ois);
				internalLists.put(index, child);
			}
									updateListData();
		} catch (IOException e) {
			System.out.println("failed to save: io");
		} catch (ClassNotFoundException e) {
			System.out.println("failed to load: file");
		}
	}

}
