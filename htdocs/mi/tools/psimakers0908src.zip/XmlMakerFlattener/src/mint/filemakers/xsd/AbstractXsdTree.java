package mint.filemakers.xsd;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.ToolTipManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

import org.exolab.castor.xml.schema.Annotated;
import org.exolab.castor.xml.schema.Annotation;
import org.exolab.castor.xml.schema.AttributeDecl;
import org.exolab.castor.xml.schema.ComplexType;
import org.exolab.castor.xml.schema.Documentation;
import org.exolab.castor.xml.schema.ElementDecl;
import org.exolab.castor.xml.schema.Group;
import org.exolab.castor.xml.schema.Order;
import org.exolab.castor.xml.schema.Particle;
import org.exolab.castor.xml.schema.Schema;
import org.exolab.castor.xml.schema.Structure;
import org.exolab.castor.xml.schema.XMLType;
import org.exolab.castor.xml.schema.reader.SchemaReader;
import org.xml.sax.InputSource;

/**
 * This Class creates and manages a Panel for a tree representation
 * of a XML schema
 * 
 * @author Arnaud Ceol, University of Rome "Tor Vergata", Mint group,
 * arnaud@cbm.bio.uniroma2.it 
 * 
 */
public abstract class AbstractXsdTree extends JPanel implements Serializable {

	public void loadSchema(File file) {
		try {
			schemaFile = file;
			FileReader xsd = new FileReader(schemaFile);
			SchemaReader reader = new SchemaReader(new InputSource(xsd));
			schema = reader.read();

			createTree();
			emptySelectionLists();
		} catch (FileNotFoundException fe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"File not found: " + file.getName(),
				"[PSI makers]",
				JOptionPane.ERROR_MESSAGE);
		} catch (IOException ioe) {
			JOptionPane.showMessageDialog(
				new JFrame(),
				"Unable to load file2",
				"[PSI makers]",
				JOptionPane.ERROR_MESSAGE);
		}
	}

	/*	DefaultTreeSelectionModel tree */
	protected JTree tree;

	/* the root node of the tree */
	protected XsdNode rootNode;

	protected DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);

	/**
	 *  if this variable is setted to true (by the constructor)
	 * while expanding a node, the tree will automaticaly 
	 * create the minimum amount of nodes required 
	 * according by the schema
	 */
	protected final boolean autoDuplicate;

	/**
	 * this hashmap keep trace of choices made by user when expanding the tree.
	 * It is usefull for example in case of saving/loading  .
	 * It associate a path (String) to a name.
	 */
	protected static ArrayList expendChoices = new ArrayList();

	/**
	 *  if this variable is setted to true (by the constructor)
	 * while expanding a node that discribe a choice, the tree will 
	 * give to the user the possibility to choose what element to expand.
	 * Else all possibility is displayed 
	 */
	protected final boolean manageChoices;

	protected JScrollPane scrollPane;

	/** dimension for buttons */
	protected final Dimension buttonsDimension = new Dimension(200, 25);

	/** the schema */
	protected static Schema schema;

	/**
	 * Returns an instance of <code>AbstractXslTree</code> 
	 *
	 * @param autoduplicate  indicates that new nodes will be automaticly 
	 * created according to the minimum defined in the schema (minOccurs) 
	 */
	public AbstractXsdTree(boolean autoduplicate, boolean manageChoices) {
		super(new BorderLayout());
		this.autoDuplicate = autoduplicate;
		this.manageChoices = manageChoices;

		tree = new JTree(treeModel);
		scrollPane = new JScrollPane(tree);

		add(scrollPane, BorderLayout.CENTER);
		add(getButtonPanel(), BorderLayout.EAST);
	}

	public AbstractXsdTree() {
		this.autoDuplicate = true;
		this.manageChoices = true;
	}
	/**
	 *  create a panel for buttons: 
	 *  her have to be added every buttons such as
	 * the ones that allows to load a schema 
	 */
	protected abstract Box getButtonPanel();

	/**
	 * the xsl file describing the schema
	 */
	protected static File schemaFile;

	/**
	 * open a file chooser allowing to choose 
	 * the file containing the schema, read it, create the tree,
	 * and finaly reinitialize everything using a previous tree.
	 * Those reinitialisations have to be defined in the 
	 * <code>emptySelectionLists</code> method
	 */
	protected void loadSchema() {
		//		try {
		JFileChooser fileChooser = new JFileChooser(".");
		int returnVal = fileChooser.showOpenDialog(this);
		if (returnVal != JFileChooser.APPROVE_OPTION) {
			return;
		}

		loadSchema(fileChooser.getSelectedFile());
	}

	/**
	 * this method should reinitialize every variable makin reference 
	 * to the actual tree, such as any <code>List</code> used to
	 * make associations to externals objects. 
	 */
	protected abstract void emptySelectionLists();

	/**
	 * when a node is clicked by the mouse, deploy it
	 * using th <code>extendPath</code> method
	 */
	public class XsdTreeSelectionListener implements TreeSelectionListener {
		public void valueChanged(TreeSelectionEvent e) {
			XsdNode node = (XsdNode) tree.getLastSelectedPathComponent();
			if (node == null)
				return;

			if (node.isExtended)
				return;
			extendPath(node);
		}
	}

	/**
	 * create the tree according to the schema loaded.
	 * The root node is displayed
	 *
	 */
	protected void createTree() {
		Enumeration elts = schema.getElementDecls();
		ElementDecl elt = (ElementDecl) elts.nextElement();

		XsdNode node = new XsdNode(elt);

		/* rootNode is mandatory */
		rootNode = node;
		rootNode.use();

		treeModel = new DefaultTreeModel(rootNode);
		tree.setModel(treeModel);
		ToolTipManager.sharedInstance().registerComponent(tree);
		setCellRenderer();
		tree.addTreeSelectionListener(new XsdTreeSelectionListener());
		tree.setShowsRootHandles(true);
	}

	/**
	 * the cell renderer used by the constructor
	 *
	 */
	protected abstract void setCellRenderer();

	/**
	 *  get the number of children with given name for a node
	 * used for example to know if the maximum number of node of that 
	 * type is already reach or to create the minimum number of node of 
	 * that type required according to the schema 
	 */
	protected int getChildrenCount(XsdNode node, String childrenName) {
		int count = 0;
		Enumeration childrens = node.children();
		while (childrens.hasMoreElements()) {
			if (((XsdNode) childrens.nextElement()).toString() == childrenName)
				count++;
		}
		return count;
	}

	/**
	 *  an enumeration of all children
	 *  add recursively to this enumeration 
	 *  the childrens of childrens if child is a choice
	 * @result a list of <code>String</code> 
	 */
	protected ArrayList getChoices(Group g) {
		ArrayList choices = new ArrayList();

		Enumeration childrens = g.enumerate();

		while (childrens.hasMoreElements()) {
			Annotated child = (Annotated) childrens.nextElement();
			choices.add(child);
		}
		return choices;
	}

	/**
	 *  check elements and attributes for the structure contained in this node
	 * create nodes 
	 * and add'em to the tree
	 */
	protected void extendPath(XsdNode node) {
		Annotated annotated = (Annotated) (node.getUserObject());
		String path = getPathForNode(node);
		switch (annotated.getStructureType()) {
			case Structure.ATTRIBUTE :
				break;

			case Structure.GROUP :
				/* if it's a complex type, look inside */
				Group g = (Group) annotated;

				XsdNode parent = (XsdNode) node.getParent();
				//				String path = getPathForNode(parent);

				/* position is important when adding new node */
				int position = parent.getIndex(node);

				/*
				 * if a sequence: add all childs
				* if a choice, ask user
				*/
				if (g.getOrder().getType() == Order.CHOICE && manageChoices) {
					ArrayList choices = getChoices(g);

					ArrayList possibilities = new ArrayList();

					for (int i = 0; i < choices.size(); i++) {
						try {
							possibilities.add(
								((ElementDecl) choices.get(i)).getName());
						} catch (ClassCastException e) {
							/* a group: give an overview */
							possibilities.add(
								choiceToString((Group) choices.get(i)));
						}
					}

					String choice =
						(String) JOptionPane.showInputDialog(
							new JFrame(),
							"what type of element do you want to add?",
							"[PSI makers] choice",
							JOptionPane.QUESTION_MESSAGE,
							new ImageIcon("images/ic-att.gif"),
							possibilities.toArray(),
							"");

					if ((choice == null) || (choice.length() == 0))
						return;

					((XsdNode) node.getParent()).remove(parent.getIndex(node));

					XsdNode newNode;

					newNode =
						new XsdNode(
							(Annotated) choices.get(
								possibilities.indexOf(choice)));

					System.out.println("add: " + path + " " + choice);
					//					expendChoices.put(path, choice);
					expendChoices.add(path);
					expendChoices.add(choice);

					newNode.isRequired = node.isRequired;
					newNode.min = node.min;
					newNode.max = node.max;
					newNode.originalParent = node;
					parent.insert(newNode, position);

					if (((Annotated) newNode.getUserObject())
						.getStructureType()
						!= Structure.GROUP)
						extendPath(newNode);
					else if (
						((Group) newNode.getUserObject()).getOrder().getType()
							!= Order.CHOICE)
						extendPath(newNode);

				} else { /* sequence */
					((XsdNode) node.getParent()).remove(parent.getIndex(node));

					Enumeration elts = g.enumerate();
					while (elts.hasMoreElements()) {

						Annotated element = (Annotated) elts.nextElement();

						XsdNode newNode = new XsdNode(element);
						parent.add(newNode);

						if (((Annotated) newNode.getUserObject())
							.getStructureType()
							!= Structure.GROUP)
							extendPath(newNode);
						else if (
							((Group) newNode.getUserObject())
								.getOrder()
								.getType()
								!= Order.CHOICE)
							extendPath(newNode);

						if (autoDuplicate) {
							if (element.getStructureType()
								== Structure.ELEMENT) {
								for (int i = 1;
									i < ((ElementDecl) element).getMinOccurs();
									i++) {

									newNode = new XsdNode(element);
									parent.add(newNode);

									if (((Annotated) newNode.getUserObject())
										.getStructureType()
										!= Structure.GROUP)
										extendPath(newNode);
									else if (
										((Group) newNode.getUserObject())
											.getOrder()
											.getType()
											!= Order.CHOICE)
										extendPath(newNode);
								}
							}
						}
					}
				}
				check((XsdNode) treeModel.getRoot());
				treeModel.reload(parent);
				break;
			case Structure.ELEMENT :
				/* if it's a complex type, look inside */
				XMLType type = ((ElementDecl) annotated).getType();
				if (type.isSimpleType())
					return;
				Enumeration attributes =
					((ComplexType) type).getAttributeDecls();
				while (attributes.hasMoreElements()) {
					node.add(new XsdNode((Annotated) attributes.nextElement()));
				}

				Enumeration elements = ((ComplexType) type).enumerate();
				while (elements.hasMoreElements()) {
					Particle ptc = (Particle) elements.nextElement();
					XsdNode child = new XsdNode((Annotated) ptc);
					node.add(child);
					if (ptc.getStructureType() != Structure.GROUP)
						extendPath(child);
					else if (
						((Group) child.getUserObject()).getOrder().getType()
							!= Order.CHOICE)
						extendPath(child);
				}

				/* do not forget the base type */
				try {
					attributes =
						((ComplexType) type.getBaseType()).getAttributeDecls();
					while (attributes.hasMoreElements()) {
						node.add(
							new XsdNode((Annotated) attributes.nextElement()));
					}
					elements = ((ComplexType) type.getBaseType()).enumerate();
					while (elements.hasMoreElements()) {
						Particle ptc = (Particle) elements.nextElement();
						XsdNode child = new XsdNode((Annotated) ptc);
						node.add(child);
						if (ptc.getStructureType() != Structure.GROUP)
							extendPath(child);
						else if (
							((Group) child.getUserObject())
								.getOrder()
								.getType()
								!= Order.CHOICE)
							extendPath(child);
					}
				} catch (Exception e) {
					/* no base type */
				}

				check((XsdNode) treeModel.getRoot());
				treeModel.reload(node);
				break;
		}
		node.isExtended = true;
	} // extendPath

	/** 
	* type for references
	* used for going deeper in case 
	* of normalized document
	*/
	protected String refType = "refType";
	protected String refAttribute = "ref";

	/**
	 * List of the types found in the schema that descrobe a reference to an element
	 * 
	 */
	protected ArrayList refTypeList = new ArrayList();

	/**
	 * retrun true if an element of this type is a reference to another element.
	 */
	protected boolean isRefType(String nodeName) {
		return refTypeList.contains(nodeName);
	}

	/**
	 * create a copy of the node and add it to the parent of this node
	 * if the node is not duplicable or if the maximum amount of this 
	 * type of node according to the schema has been reached, do nothing 
	 * @param node the node to duplicate
	 */
	protected void duplicateNode(XsdNode node) {
		if (!node.isDuplicable())
			return;
		if (node.max
			== getChildrenCount((XsdNode) node.getParent(), node.toString()))
			return;

		//		XslNode child = (XslNode) node.clone();
		XsdNode child = node.createBrother();

		XsdNode parentNode = (XsdNode) node.getParent();
		treeModel.insertNodeInto(child, parentNode, parentNode.getIndex(node));

		/* be sure that this node is not already used */
		child.init();

		if (((Annotated) child.getUserObject()).getStructureType()
			!= Structure.GROUP)
			extendPath(child);
		else if (
			((Group) child.getUserObject()).getOrder().getType()
				!= Order.CHOICE)
			extendPath(child);
	}

	/**
	 * @author arnaud
	 *
	 * The renderer for the tree
	 */
	protected class XsdTreeRenderer extends DefaultTreeCellRenderer {
		ImageIcon iconAttribute;
		ImageIcon iconElement;
		Font affected;
		public XsdTreeRenderer() {
			iconAttribute = new ImageIcon("images/ic-att.gif");
			iconElement = new ImageIcon("images/ic-elt.gif");
		}

		public Component getTreeCellRendererComponent(
			JTree tree,
			Object value,
			boolean sel,
			boolean expanded,
			boolean leaf,
			int row,
			boolean hasFocus) {

			super.getTreeCellRendererComponent(
				tree,
				value,
				sel,
				expanded,
				leaf,
				row,
				hasFocus);
			XsdNode node = (XsdNode) value;
			/* set icon and tooltip */
			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.GROUP :
					setIcon(null);
					break;
				case Structure.ATTRIBUTE :
					setIcon(iconAttribute);
					setToolTipText(
						"default value: "
							+ ((AttributeDecl) node.getUserObject())
								.getDefaultValue());
					break;
				case Structure.ELEMENT :
					setIcon(iconElement);
					try {
						setToolTipText(
							(
								(Documentation)
									((Annotation) ((ElementDecl) node
									.getUserObject())
								.getAnnotations()
								.nextElement())
								.getDocumentation()
								.nextElement())
								.getContent());
					} catch (Exception e) {
						setToolTipText("no documentation");
					}

					break;
			}

			switch (((Annotated) node.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					setText(
						getText()
							+ " ("
							+ ((AttributeDecl) node.getUserObject())
								.getSimpleType()
								.getName()
							+ ")");
					break;
				case Structure.ELEMENT :
					setText(
						getText()
							+ " ("
							+ ((ElementDecl) node.getUserObject())
								.getType()
								.getName()
							+ ")");
			}

			return this;
		}
	}

	/**
	 * describes the node with informations such as its name or its XML type.
	 * Other informations should probably have to be added when extending this class 
	 * @param node the node on which informations are required
	 * @return a string describing informations about the node
	 */
	protected String getInfos(XsdNode node) {
		String infos = "";
	
		/* name */
		infos += "name: " + node.toString() + "\n";

		/* XML type */
		infos += "Xml type: ";
		switch (((Annotated) node.getUserObject()).getStructureType()) {
			case Structure.ATTRIBUTE :
				infos += "attribute\n\n";
				infos += "This node is ";
				if (!((AttributeDecl) node.getUserObject()).isRequired())
					infos += "not ";
				infos += "required\n";
				break;
			case Structure.ELEMENT :
				infos += "element\n";
				infos += "minimum occurences: " + node.min + "\n";
				infos += "maximum occurences: ";
				if (node.max >= 0)
					infos += node.max + "\n";
				else
					infos += "unbounded\n\n";
				infos += "This node is ";
				if (((ElementDecl) node.getUserObject()).getMinOccurs() == 0)
					infos += "not ";
				infos += "required\n";
				break;
			default :
				infos += "not XML\n";
		}

		return infos;
	}

	/**
	 * return a understandable <code>String</code> describing the path of a node,
	 * on type: "grandparentNode.ParentNode.Node"
	 * @param path the path to describe
	 * @return an understandable <code>String</code> to describe the node
	 */
	protected String printPath(TreeNode[] path) {
		String value = "";
		for (int i = 0; i < path.length; i++) {
			if (((Annotated) ((XsdNode) path[i]).getUserObject())
				.getStructureType()
				!= Structure.GROUP)
				value += "[" + ((XsdNode) path[i]).toString() + "]";
		}
		return value;
	}

	/**
	 * a node ca have a value if it is an attribute or if it has a simple content
	 * @param node a node
	 * @return true if the node can have a value
	 */
	protected boolean canHaveValue(XsdNode node) {
		if (((Annotated) node.getUserObject()).getStructureType()
			== Structure.ATTRIBUTE)
			return true;

		if (!((ElementDecl) node.getUserObject()).getType().isComplexType())
			return true;

		if (((ElementDecl) node.getUserObject()).getType().getBaseType()
			!= null) {
			if (!((ElementDecl) node.getUserObject())
				.getType()
				.getBaseType()
				.isComplexType())
				return true;
		}
		return false;
	}

	/**
	 * check for errors on this node (lack of associations...) a return an array 
	 * of understandable Strings describing the errors
	 * @param node the node to check
	 * @return an array of Strings describing the errors found
	 */
	protected abstract ArrayList check(XsdNode node);

	/**
	 * this class extends DefaultMutableTreeNode for giving it a more 
	 * understandable toString function, 'cuz this function is used for the display of nodes
	 */
	protected class XsdNode
		extends DefaultMutableTreeNode
		implements Serializable {

		public boolean isExtended = false;
		public boolean isCheckedOk = false;
		public boolean isRequired;
		public boolean isUsed;
		private int use;

		/* keep trace of the parent of this node for choices */
		public XsdNode originalParent = null;

		public int min;
		public int max;

		public XsdNode createBrother() {
			XsdNode brother = new XsdNode();
			brother.setUserObject((Annotated) this.getUserObject());

			brother.isRequired = this.isRequired;
			brother.min = this.min;
			brother.max = this.max;
			if (this.originalParent != null) {
				brother.originalParent = this.originalParent.createBrother();
			}
			return brother;
		}

		public boolean isDuplicable() {
			return max > 1 || max == -1;
		}

		public void init() {
			isUsed = false;
			int use = 0;
		}

		public XsdNode() {
			super();
		}

		public XsdNode(Annotated aValue) {
			super(aValue);
			try {
				if (((AttributeDecl) aValue).isRequired()) {
					isRequired = true;
					min = 1;
				}
				max = 1;
			} catch (ClassCastException e) {
				try {
					if (((Particle) aValue).getMinOccurs() != 0) {
						isRequired = true;
						min = ((Particle) aValue).getMinOccurs();
					}
					max = ((Particle) aValue).getMaxOccurs();

				} catch (ClassCastException e2) {
				}
			}

			try {
				/* ref type */
				if (((ElementDecl) aValue)
					.getType()
					.getName()
					.compareTo(refType)
					== 0
					&& !refTypeList.contains(this.toString())) {
					refTypeList.add(this.toString());
				}
			} catch (Exception e2) {
			}
		}

		public void use() {
			use++;
			if (this.getParent() != null) {
				((XsdNode) this.getParent()).use();
			}
			isUsed = true;
		}

		public void useOnlyThis() {
			use();
			//			use++;
			//			isUsed = true;
		}

		public void unuseOnlyThis() {
			unuse();
			//			use--;
			//			isUsed = use > 0;
		}

		public void unuse() {
			use--;
			if (this.getParent() != null) {
				((XsdNode) this.getParent()).unuse();
			}
			isUsed = use > 0;
		}

		public String toString() {
			switch (((Annotated) this.getUserObject()).getStructureType()) {
				case Structure.ATTRIBUTE :
					return ((AttributeDecl) this.getUserObject()).getName();
				case Structure.ELEMENT :
					return ((ElementDecl) this.getUserObject()).getName();
				case Structure.GROUP :
					return choiceToString((Group) this.getUserObject());

				default :
					return ((Annotated) this.getUserObject()).toString();
			}
		}
	}

	/**
	 * transforms a list of choices returned for example by 
	 * the methods <code>getChoices</code> and create a single
	 * <code>String</code> to describe it using for example "|" symbol 
	 * to express a choice between two elements 
	 * @param g a single <code>String</code> to describe a list of choices
	 * @return
	 */
	protected String choiceToString(Group g) {
		Enumeration children = g.enumerate();

		String init;
		String delimiter = "";

		if (g.getOrder().getType() == Order.CHOICE)
			init = " | ";
		else
			init = " & ";

		String value = "(";

		while (children.hasMoreElements()) {
			Annotated child = (Annotated) children.nextElement();
			switch (child.getStructureType()) {
				case Structure.ATTRIBUTE :
					value += delimiter + ((AttributeDecl) child).getName();
					break;
				case Structure.ELEMENT :
					value += delimiter + ((ElementDecl) child).getName();
					break;
				default :
					value += delimiter + choiceToString((Group) child);
			}
			delimiter = init;
		}
		return value + ")";
	}

	protected void redoChoice(String path, String choice) {
		XsdNode currentNode = rootNode;
		/* never a choice on rootNode */
		String nextIndexes = path.substring(path.indexOf(".") + 1);
		int index = 0;

		/* for each element on the path */
		//		while (nextIndexes.indexOf(".") >= 0) {
		while (nextIndexes.length() > 0) {
				/* if choice do it */
			Annotated annotated = (Annotated) (currentNode.getUserObject());
			if (annotated.getStructureType() == Structure.GROUP) {
				/* if it's a complex type, look inside */

				Group g = (Group) annotated;
				try {
					if (g.getOrder().getType() == Order.CHOICE
						&& manageChoices) {
						XsdNode parent = (XsdNode) currentNode.getParent();
						int position = parent.getIndex(currentNode);
						ArrayList choices = getChoices(g);
						ArrayList possibilities = new ArrayList();
						for (int i = 0; i < choices.size(); i++) {
							try {
								possibilities.add(
									((ElementDecl) choices.get(i)).getName());
							} catch (ClassCastException e) {
								/* a group: give an overview */
								possibilities.add(
									choiceToString((Group) choices.get(i)));
							}
						}
						//						String choice = (String) expendChoices.get(path);
						((XsdNode) currentNode.getParent()).remove(
							parent.getIndex(currentNode));
						XsdNode newNode;
						newNode =
							new XsdNode(
								(Annotated) choices.get(
									possibilities.indexOf(choice)));
						newNode.isRequired = currentNode.isRequired;
						newNode.min = currentNode.min;
						newNode.max = currentNode.max;
						newNode.originalParent = currentNode;
						parent.insert(newNode, position);
						currentNode = newNode;
					} else {
						/* if not  extended, do it */
						if (!currentNode.isExtended) {
							extendPath(currentNode);
						} else {
							index =
								Integer.parseInt(
									nextIndexes.substring(
										0,
										nextIndexes.indexOf(".")));
							nextIndexes =
								nextIndexes.substring(
									nextIndexes.indexOf(".") + 1);
							currentNode =
								(XsdNode) currentNode.getChildAt(index);
						}
					}
				} catch (StringIndexOutOfBoundsException e) {
					return;
				}
			} else {
				/* if not  extended, do it */
				if (!currentNode.isExtended) {
					extendPath(currentNode);
				} else {
					if (nextIndexes.indexOf(".") >= 0) {
						index =
							Integer.parseInt(
								nextIndexes.substring(
									0,
									nextIndexes.indexOf(".")));
						nextIndexes =
							nextIndexes.substring(nextIndexes.indexOf(".") + 1);
						currentNode = (XsdNode) currentNode.getChildAt(index);
					} else {

						index = Integer.parseInt(nextIndexes);
						nextIndexes = "-1";
						try {
							currentNode =
								(XsdNode) currentNode.getChildAt(index);
						} catch (ArrayIndexOutOfBoundsException e) {
							return;
						}
					}
				}
			}
		}
	}

	//	protected XsdNode redoChoice(XsdNode currentNode) {
	//		if (currentNode == rootNode)
	//			return currentNode;
	//
	//		String path = getPathForNode(currentNode);
	//		Annotated annotated = (Annotated) (currentNode.getUserObject());
	//		if (annotated.getStructureType() == Structure.GROUP) {
	//			/* if it's a complex type, look inside */
	//			Group g = (Group) annotated;
	//			if (g.getOrder().getType() == Order.CHOICE && manageChoices) {
	//				XsdNode parent = (XsdNode) currentNode.getParent();
	//				int position = parent.getIndex(currentNode);
	//				ArrayList choices = getChoices(g);
	//				ArrayList possibilities = new ArrayList();
	//				for (int i = 0; i < choices.size(); i++) {
	//					try {
	//						possibilities.add(
	//							((ElementDecl) choices.get(i)).getName());
	//					} catch (ClassCastException e) {
	//						/* a group: give an overview */
	//						possibilities.add(
	//							choiceToString((Group) choices.get(i)));
	//					}
	//				}
	//				String choice = (String) expendChoices.get(path);
	//				((XsdNode) currentNode.getParent()).remove(
	//					parent.getIndex(currentNode));
	//				XsdNode newNode;
	//				newNode =
	//					new XsdNode(
	//						(Annotated) choices.get(possibilities.indexOf(choice)));
	//				newNode.isRequired = currentNode.isRequired;
	//				newNode.min = currentNode.min;
	//				newNode.max = currentNode.max;
	//				newNode.originalParent = currentNode;
	//				parent.insert(newNode, position);
	//				return newNode;
	//			}
	//		}
	//		return currentNode;
	//	}

	/**
	 * follow indexes in the tree and return the node found
	 * @param indexes a string describing the indexes, e.g. 1.1.2.1
	 */
	public XsdNode getNodeByIndexes(String indexes) {
		String nextIndexes = indexes;
		XsdNode currentNode = null; //rootNode;
		//		redoChoice(currentNode);
		//		extendPath(currentNode);
		int index = 0;

		while (nextIndexes.indexOf(".") >= 0) {
			index =
				Integer.parseInt(
					nextIndexes.substring(0, nextIndexes.indexOf(".")));
			nextIndexes = nextIndexes.substring(nextIndexes.indexOf(".") + 1);
			if (currentNode == null) {
				currentNode = rootNode;
			} else {
				//				currentNode = redoChoice(currentNode);
				if (!currentNode.isExtended) {
					extendPath(currentNode);
				}
				currentNode = (XsdNode) currentNode.getChildAt(index);
			}
			//			redoChoice(currentNode);
		}
		index = Integer.parseInt(nextIndexes);
		/* no more "." in the path just a last index */
		if (currentNode == null)
			return rootNode;
		//		
		//		if (!currentNode.isExtended) {
		//			redoChoice(currentNode);
		//			extendPath(currentNode);
		//		}
		//		

		//		currentNode = redoChoice(currentNode);
		if (!currentNode.isExtended) {
			extendPath(currentNode);
		}
		currentNode = (XsdNode) currentNode.getChildAt(index);
		/** TODO errors if node do not exist */
		return currentNode;
	}

	/**
	 * return a String describing the indexes to follow to go from root node to target node
	 * @param node 
	 * @return
	 */
	public String getPathForNode(XsdNode node) {
		TreeNode nodesPath[] = node.getPath();
		String path = "0";
		for (int i = 0; i < nodesPath.length - 1; i++) {
			path += "." + nodesPath[i].getIndex(nodesPath[i + 1]);
		}
		return path;
	}

	protected void displayMessage(String message, String title) {

		JEditorPane editorPane = new JEditorPane();
		editorPane.setEditable(false);
		editorPane.setText(message);
		JScrollPane errorScrollPane = new JScrollPane(editorPane);
		JFrame frame = new JFrame();
		frame.setSize(400, 300);
		frame.getContentPane().add(errorScrollPane);
		frame.show();
	}

	public void reload() {
		treeModel.reload();
	}

}