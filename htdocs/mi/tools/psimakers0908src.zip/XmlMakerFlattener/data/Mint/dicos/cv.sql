select term_without_spaces, term_without_spaces, mi_id from mint_cv;
